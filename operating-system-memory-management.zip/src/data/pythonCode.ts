export const pythonCode = `# ============================================================
#  GESTOR DE MEMORIA MINIMO - Taller de Sistemas Operativos
#  RAM: 32 marcos x 8 KB = 256 KB | Asignacion: primer ajuste
# ============================================================

import math

FRAME_SIZE = 8          # KB por marco / pagina
NUM_FRAMES = 32         # marcos totales de RAM
ram        = [None] * NUM_FRAMES   # marco -> pid o None
procesos   = {}         # pid -> {nombre, tam, paginas, marcos, en_swap}
siguiente_pid = 1


def primer_ajuste(n):
    """Devuelve el indice inicial de n marcos libres contiguos, o -1."""
    corrida = 0
    for i in range(NUM_FRAMES):
        corrida = corrida + 1 if ram[i] is None else 0
        if corrida == n:
            return i - n + 1
    return -1


def mostrar_memoria():
    print("\\n  RAM (" + str(NUM_FRAMES * FRAME_SIZE) + " KB):")
    for i in range(0, NUM_FRAMES, 8):
        fila = ""
        for j in range(i, i + 8):
            celda = "----" if ram[j] is None else f"P{ram[j]:<3}"
            fila += f"[{j:2}:{celda}] "
        print("  " + fila)
    libres = ram.count(None)
    print(f"  Usados: {NUM_FRAMES - libres} marcos | Libres: {libres} marcos")
    for pid, p in procesos.items():
        lugar = "SWAP" if p["en_swap"] else f"marcos {p['marcos']}"
        print(f"  PID {pid} {p['nombre']:10} {p['tam']:4} KB "
              f"({p['paginas']} pag.) -> {lugar}")


def crear_proceso():
    global siguiente_pid
    nombre = input("  Nombre del proceso: ").strip() or f"P{siguiente_pid}"
    tam    = int(input("  Tamano en KB: "))
    pags   = math.ceil(tam / FRAME_SIZE)
    inicio = primer_ajuste(pags)
    if inicio == -1:
        if ram.count(None) >= pags:
            print("  [!] Hay memoria libre pero no contigua "
                  "(fragmentacion externa). Compacte e intente de nuevo.")
        else:
            print("  [X] Memoria insuficiente.")
        return
    marcos = list(range(inicio, inicio + pags))
    for m in marcos:
        ram[m] = siguiente_pid
    procesos[siguiente_pid] = {"nombre": nombre, "tam": tam,
                               "paginas": pags, "marcos": marcos,
                               "en_swap": False}
    print(f"  [OK] {nombre} creado con PID {siguiente_pid} "
          f"en marcos {inicio}-{inicio + pags - 1}.")
    siguiente_pid += 1


def terminar_proceso():
    pid = int(input("  PID a terminar: "))
    p = procesos.pop(pid, None)
    if p is None:
        print("  [X] PID no existe.")
        return
    for m in p["marcos"] or []:
        ram[m] = None
    print(f"  [OK] {p['nombre']} terminado y memoria liberada.")


def compactar():
    cursor = 0
    for i in range(NUM_FRAMES):
        ram[i] = None
    for pid in sorted(procesos,
                      key=lambda x: (procesos[x]["marcos"] or [NUM_FRAMES])[0]):
        p = procesos[pid]
        if p["en_swap"]:
            continue
        p["marcos"] = list(range(cursor, cursor + p["paginas"]))
        for m in p["marcos"]:
            ram[m] = pid
        cursor += p["paginas"]
    print("  [OK] Memoria compactada: un solo hueco libre contiguo.")


def mostrar_paginas():
    pid = int(input("  PID: "))
    p = procesos.get(pid)
    if p is None:
        print("  [X] PID no existe.")
        return
    print(f"  Tabla de paginas de {p['nombre']} "
          f"(frag. interna: {p['paginas'] * FRAME_SIZE - p['tam']} KB)")
    for i in range(p["paginas"]):
        destino = "DISCO (swap)" if p["en_swap"] else f"marco {p['marcos'][i]}"
        print(f"    pagina {i:2} -> {destino}")


def enviar_a_swap():
    pid = int(input("  PID a enviar a SWAP: "))
    p = procesos.get(pid)
    if p is None or p["en_swap"]:
        print("  [X] PID invalido o ya esta en SWAP.")
        return
    for m in p["marcos"]:
        ram[m] = None
    p["marcos"], p["en_swap"] = None, True
    print(f"  [OK] {p['nombre']} movido al area de SWAP (swap-out).")


def recuperar_de_swap():
    pid = int(input("  PID a recuperar: "))
    p = procesos.get(pid)
    if p is None or not p["en_swap"]:
        print("  [X] PID invalido o no esta en SWAP.")
        return
    inicio = primer_ajuste(p["paginas"])
    if inicio == -1:
        print("  [!] No hay hueco contiguo suficiente. Compacte primero.")
        return
    p["marcos"] = list(range(inicio, inicio + p["paginas"]))
    for m in p["marcos"]:
        ram[m] = pid
    p["en_swap"] = False
    print(f"  [OK] {p['nombre']} recuperado (swap-in) "
          f"en marcos {inicio}-{inicio + p['paginas'] - 1}.")


MENU = """
================ GESTOR DE MEMORIA ================
  1. Mostrar memoria        5. Mostrar paginas
  2. Crear proceso          6. Enviar proceso a SWAP
  3. Terminar proceso       7. Recuperar proceso de SWAP
  4. Compactar memoria      8. Salir
==================================================="""

OPCIONES = {"1": mostrar_memoria, "2": crear_proceso,
            "3": terminar_proceso, "4": compactar,
            "5": mostrar_paginas, "6": enviar_a_swap,
            "7": recuperar_de_swap}

if __name__ == "__main__":
    while True:
        print(MENU)
        opcion = input("  Opcion: ").strip()
        if opcion == "8":
            print("  Hasta pronto.")
            break
        OPCIONES.get(opcion, lambda: print("  [X] Opcion invalida."))()
`;
