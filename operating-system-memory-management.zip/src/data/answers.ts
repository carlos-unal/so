export interface QA {
  question: string;
  answer: string;
}

export interface Section {
  id: string;
  number: number;
  title: string;
  icon: string;
  items: QA[];
}

export const sections: Section[] = [
  {
    id: "conceptos",
    number: 1,
    title: "Conceptos básicos y administración del almacenamiento",
    icon: "🧩",
    items: [
      {
        question: "¿Qué diferencia existe entre asignación contigua y no contigua?",
        answer:
          "La asignación contigua exige que el proceso ocupe un solo bloque de memoria adyacente, mientras que la no contigua permite dividirlo en fragmentos ubicados en distintos huecos, lo que es más difícil de administrar pero aprovecha mejor la memoria dispersa.",
      },
      {
        question: "¿Qué función cumplen las políticas de obtención, colocación y reemplazo?",
        answer:
          "Las políticas de obtención definen cuándo traer una parte del programa a memoria, las de colocación determinan dónde ubicarlo, y las de reemplazo deciden qué desalojar cuando la memoria está llena y se necesita espacio.",
      },
      {
        question: "¿Qué significan primer ajuste, mejor ajuste y peor ajuste?",
        answer:
          "El primer ajuste coloca el proceso en el primer hueco suficiente que encuentra; el mejor ajuste busca el hueco más ajustado posible para minimizar el desperdicio; y el peor ajuste elige el hueco más grande, dejando un residuo que se espera siga siendo útil.",
      },
    ],
  },
  {
    id: "mono-multi",
    number: 2,
    title: "Monoprogramación vs. multiprogramación",
    icon: "⚙️",
    items: [
      {
        question: "¿Cuántos procesos pueden encontrarse en memoria en monoprogramación?",
        answer: "En la monoprogramación solo puede haber un proceso de usuario en memoria a la vez.",
      },
      {
        question: "¿Qué problema presenta este esquema?",
        answer:
          "Este esquema desperdicia memoria y deja la CPU ociosa cada vez que el proceso hace una operación de entrada/salida, al no haber otro proceso disponible.",
      },
      {
        question: "¿Por qué aparece la multiprogramación?",
        answer:
          "La multiprogramación surge para aprovechar mejor la CPU, permitiendo que varios procesos convivan en memoria y se ejecuten de forma concurrente.",
      },
      {
        question: "¿Qué ocurre con la CPU mientras un proceso espera una operación de E/S?",
        answer:
          "Mientras un proceso espera una operación de E/S, el sistema operativo asigna la CPU a otro proceso, evitando que quede inactiva.",
      },
    ],
  },
  {
    id: "particiones",
    number: 3,
    title: "Particiones fijas y variables",
    icon: "📐",
    items: [
      {
        question: "¿Qué es una partición fija?",
        answer:
          "Es una división de la memoria realizada de antemano (al arrancar el sistema) en bloques de tamaño predefinido e invariable. Cada proceso se carga en una partición completa aunque no la llene, por lo que el espacio sobrante dentro de ella se desperdicia (fragmentación interna).",
      },
      {
        question: "¿Qué es una partición variable?",
        answer:
          "Es una división dinámica de la memoria: a cada proceso se le asigna un bloque exactamente del tamaño que necesita en el momento en que llega. Las particiones se crean y liberan sobre la marcha, de modo que su número y tamaño cambian con el tiempo y van quedando huecos entre procesos (fragmentación externa).",
      },
      {
        question: "¿Cuál aprovecha mejor la memoria?",
        answer:
          "Las particiones variables, porque asignan a cada proceso solo lo que requiere y eliminan la fragmentación interna. Su costo es una administración más compleja y la aparición de fragmentación externa, que puede corregirse con compactación.",
      },
      {
        question: "¿Qué es la fragmentación?",
        answer:
          "Es el desperdicio de memoria que impide usarla aunque exista espacio libre. La fragmentación interna es el espacio que sobra dentro de una partición asignada (más grande que el proceso); la fragmentación externa son los huecos libres dispersos entre procesos, que en conjunto bastarían para alojar un proceso pero que por no ser contiguos no pueden usarse.",
      },
      {
        question: "¿Qué función cumple la compactación?",
        answer:
          "Reubica (desplaza) los procesos en memoria para juntarlos en un extremo, fusionando todos los huecos pequeños dispersos en un único bloque libre contiguo y grande. Así elimina la fragmentación externa, aunque tiene un costo alto en tiempo de CPU por el movimiento de datos.",
      },
    ],
  },
  {
    id: "virtual",
    number: 4,
    title: "Memoria virtual y paginación",
    icon: "🪄",
    items: [
      {
        question: "¿Qué es memoria virtual?",
        answer:
          "Es una técnica que crea la ilusión de que la memoria principal (RAM) es más grande de lo que realmente es. Permite que los programas no tengan que estar cargados completamente en RAM para ejecutarse: el sistema operativo mantiene en memoria solo las partes del código y los datos que están en uso, y deja el resto en almacenamiento secundario (disco duro o SSD), trayéndolo a RAM únicamente cuando se necesita. Gracias a esto el sistema puede ejecutar aplicaciones más grandes que la RAM física, aumentar el nivel de multiprogramación y aislar los procesos para que uno no afecte a otro.",
      },
      {
        question: "¿Cuál es la diferencia entre dirección virtual y dirección física?",
        answer:
          "La dirección virtual (o lógica) es la que genera el programa durante su ejecución y pertenece a su propio espacio de direcciones, que comienza en cero. La dirección física es la posición real dentro de la memoria RAM. El proceso solo conoce direcciones virtuales; la traducción a direcciones físicas la realiza el hardware (MMU) en tiempo de ejecución.",
      },
      {
        question: "¿Qué hace la MMU?",
        answer:
          "La MMU (Memory Management Unit) es el componente de hardware que traduce, en cada acceso a memoria, las direcciones virtuales que emite la CPU en direcciones físicas reales, consultando la tabla de páginas del proceso. Además verifica permisos y protección, y dispara una excepción (page fault) cuando la página referenciada no está en RAM.",
      },
      {
        question: "¿Qué es una página?",
        answer:
          "Es cada uno de los bloques de tamaño fijo (por ejemplo 4 KB) en que se divide el espacio de direcciones virtual de un proceso. El proceso se compone de páginas numeradas que pueden cargarse en memoria de forma no contigua.",
      },
      {
        question: "¿Qué es un marco de página?",
        answer:
          "Es cada uno de los bloques de tamaño fijo en que se divide la memoria física (RAM), del mismo tamaño que una página. Cualquier página de cualquier proceso puede colocarse en cualquier marco libre; la tabla de páginas registra qué página ocupa qué marco.",
      },
      {
        question: "¿Qué ocurre cuando se produce un page fault?",
        answer:
          "Ocurre cuando el proceso referencia una página que no está en RAM. La MMU genera una excepción, el sistema operativo suspende al proceso, localiza la página en disco, busca un marco libre (o desaloja una página víctima según la política de reemplazo), carga la página en el marco, actualiza la tabla de páginas y reanuda el proceso, que repite la instrucción como si nada hubiera pasado.",
      },
    ],
  },
  {
    id: "swapping",
    number: 5,
    title: "Swapping",
    icon: "🔁",
    items: [
      {
        question: "¿Qué es swapping?",
        answer:
          "Es la técnica mediante la cual el sistema operativo mueve procesos completos (o partes de ellos) desde la memoria RAM hacia el disco y viceversa, para liberar memoria principal y permitir que más procesos puedan ejecutarse de los que caben físicamente en RAM.",
      },
      {
        question: "¿Por qué un proceso pasa de RAM a disco?",
        answer:
          "Porque la memoria principal se agota y el sistema necesita espacio para otros procesos con mayor prioridad o listos para ejecutar. Normalmente se expulsan procesos bloqueados, inactivos o de baja prioridad, liberando sus marcos para quien los necesite.",
      },
      {
        question: "¿Qué es el área de swap?",
        answer:
          "Es una zona reservada del almacenamiento secundario (una partición o archivo especial del disco) destinada a guardar la imagen de los procesos o páginas que fueron expulsados de la RAM, de forma que puedan recuperarse después tal como estaban.",
      },
      {
        question: "¿Qué ocurre cuando posteriormente ese proceso necesita ejecutarse?",
        answer:
          "El sistema operativo lo trae de vuelta del área de swap a la RAM (swap-in), asignándole marcos libres —no necesariamente las mismas direcciones que ocupaba antes—, actualiza sus tablas y lo pone de nuevo en la cola de listos para que continúe su ejecución donde quedó.",
      },
    ],
  },
];
