import { useMemo, useRef, useState } from "react";

/* ─────────────── Modelo del gestor de memoria ─────────────── */

const FRAME_SIZE = 8; // KB por marco / página
const NUM_FRAMES = 32; // 32 marcos × 8 KB = 256 KB de RAM
const RAM_KB = FRAME_SIZE * NUM_FRAMES;

interface Proceso {
  pid: number;
  name: string;
  size: number; // KB solicitados
  pages: number; // páginas = ceil(size / FRAME_SIZE)
  frames: number[] | null; // marcos asignados (contiguos) o null si está en swap
  inSwap: boolean;
  color: string;
}

interface LogEntry {
  time: string;
  kind: "ok" | "warn" | "err" | "info";
  msg: string;
}

const PALETTE = [
  { bg: "bg-sky-500", soft: "bg-sky-100 text-sky-800 border-sky-300", hex: "#0ea5e9" },
  { bg: "bg-emerald-500", soft: "bg-emerald-100 text-emerald-800 border-emerald-300", hex: "#10b981" },
  { bg: "bg-amber-500", soft: "bg-amber-100 text-amber-800 border-amber-300", hex: "#f59e0b" },
  { bg: "bg-fuchsia-500", soft: "bg-fuchsia-100 text-fuchsia-800 border-fuchsia-300", hex: "#d946ef" },
  { bg: "bg-rose-500", soft: "bg-rose-100 text-rose-800 border-rose-300", hex: "#f43f5e" },
  { bg: "bg-indigo-500", soft: "bg-indigo-100 text-indigo-800 border-indigo-300", hex: "#6366f1" },
  { bg: "bg-teal-500", soft: "bg-teal-100 text-teal-800 border-teal-300", hex: "#14b8a6" },
  { bg: "bg-orange-500", soft: "bg-orange-100 text-orange-800 border-orange-300", hex: "#f97316" },
];

/** Busca con PRIMER AJUSTE una corrida de `n` marcos libres contiguos. */
function firstFit(occupied: (number | null)[], n: number): number {
  let run = 0;
  for (let i = 0; i < NUM_FRAMES; i++) {
    run = occupied[i] === null ? run + 1 : 0;
    if (run === n) return i - n + 1;
  }
  return -1;
}

/* ─────────────── Componente ─────────────── */

export default function Simulator() {
  const [procs, setProcs] = useState<Proceso[]>([]);
  const [nextPid, setNextPid] = useState(1);
  const [log, setLog] = useState<LogEntry[]>([
    { time: timeNow(), kind: "info", msg: `Gestor iniciado · RAM = ${RAM_KB} KB · ${NUM_FRAMES} marcos de ${FRAME_SIZE} KB` },
  ]);
  const [name, setName] = useState("");
  const [size, setSize] = useState(40);
  const [selectedPid, setSelectedPid] = useState<number | null>(null);
  const [showPages, setShowPages] = useState(true);
  const logRef = useRef<HTMLDivElement>(null);

  function timeStamp(kind: LogEntry["kind"], msg: string) {
    setLog((l) => [...l, { time: timeNow(), kind, msg }]);
    setTimeout(() => logRef.current?.scrollTo({ top: 99999, behavior: "smooth" }), 50);
  }

  /** Mapa marco → pid (o null si libre). */
  const frameMap: (number | null)[] = useMemo(() => {
    const map: (number | null)[] = Array(NUM_FRAMES).fill(null);
    for (const p of procs) if (p.frames) for (const f of p.frames) map[f] = p.pid;
    return map;
  }, [procs]);

  const inRam = procs.filter((p) => !p.inSwap);
  const inSwap = procs.filter((p) => p.inSwap);
  const usedFrames = frameMap.filter((f) => f !== null).length;
  const freeFrames = NUM_FRAMES - usedFrames;
  const intFrag = inRam.reduce((a, p) => a + (p.pages * FRAME_SIZE - p.size), 0);

  /** Huecos libres contiguos (fragmentación externa). */
  const holes = useMemo(() => {
    const h: { start: number; len: number }[] = [];
    let start = -1;
    for (let i = 0; i <= NUM_FRAMES; i++) {
      const free = i < NUM_FRAMES && frameMap[i] === null;
      if (free && start === -1) start = i;
      if (!free && start !== -1) {
        h.push({ start, len: i - start });
        start = -1;
      }
    }
    return h;
  }, [frameMap]);

  /* ───── 2. Crear proceso ───── */
  function crearProceso() {
    const pname = name.trim() || `P${nextPid}`;
    if (size <= 0 || size > RAM_KB) {
      timeStamp("err", `✗ Tamaño inválido: debe estar entre 1 y ${RAM_KB} KB.`);
      return;
    }
    const pages = Math.ceil(size / FRAME_SIZE);
    const start = firstFit(frameMap, pages);
    if (start === -1) {
      if (freeFrames >= pages) {
        timeStamp(
          "warn",
          `⚠ No hay un hueco contiguo de ${pages} marcos para ${pname}, aunque hay ${freeFrames} marcos libres dispersos → fragmentación externa. Pruebe «Compactar memoria».`,
        );
      } else {
        timeStamp("err", `✗ Memoria insuficiente para ${pname} (${size} KB = ${pages} páginas). Libere o envíe procesos a SWAP.`);
      }
      return;
    }
    const frames = Array.from({ length: pages }, (_, i) => start + i);
    const proc: Proceso = {
      pid: nextPid,
      name: pname,
      size,
      pages,
      frames,
      inSwap: false,
      color: PALETTE[(nextPid - 1) % PALETTE.length].bg,
    };
    setProcs((ps) => [...ps, proc]);
    setNextPid((n) => n + 1);
    setSelectedPid(proc.pid);
    setName("");
    timeStamp(
      "ok",
      `✓ ${pname} (PID ${proc.pid}) creado: ${size} KB → ${pages} páginas, marcos ${start}–${start + pages - 1} (primer ajuste). Fragmentación interna: ${pages * FRAME_SIZE - size} KB.`,
    );
  }

  /* ───── 3. Terminar proceso ───── */
  function terminarProceso(pid: number) {
    const p = procs.find((x) => x.pid === pid);
    if (!p) return;
    setProcs((ps) => ps.filter((x) => x.pid !== pid));
    if (selectedPid === pid) setSelectedPid(null);
    timeStamp("ok", `✓ ${p.name} (PID ${pid}) terminado. ${p.inSwap ? "Se liberó su espacio en el área de SWAP." : `Se liberaron ${p.pages} marcos de RAM.`}`);
  }

  /* ───── 4. Compactar memoria ───── */
  function compactar() {
    if (inRam.length === 0) {
      timeStamp("warn", "⚠ No hay procesos en RAM para compactar.");
      return;
    }
    let cursor = 0;
    const ordered = [...inRam].sort((a, b) => (a.frames![0] ?? 0) - (b.frames![0] ?? 0));
    const moved: string[] = [];
    setProcs((ps) =>
      ps.map((p) => {
        if (p.inSwap || !p.frames) return p;
        const idx = ordered.findIndex((o) => o.pid === p.pid);
        let start = 0;
        for (let i = 0; i < idx; i++) start += ordered[i].pages;
        cursor = start;
        if (p.frames[0] !== start) moved.push(`${p.name}: marco ${p.frames[0]} → ${start}`);
        return { ...p, frames: Array.from({ length: p.pages }, (_, i) => start + i) };
      }),
    );
    void cursor;
    timeStamp(
      moved.length ? "ok" : "info",
      moved.length
        ? `✓ Memoria compactada. Procesos reubicados → ${moved.join(" · ")}. Ahora hay un único hueco libre contiguo de ${freeFrames} marcos.`
        : "ℹ La memoria ya estaba compactada: no hubo reubicaciones.",
    );
  }

  /* ───── 6. Enviar a SWAP ───── */
  function swapOut(pid: number) {
    const p = procs.find((x) => x.pid === pid);
    if (!p || p.inSwap) return;
    setProcs((ps) => ps.map((x) => (x.pid === pid ? { ...x, frames: null, inSwap: true } : x)));
    timeStamp("ok", `✓ ${p.name} (PID ${pid}) enviado al área de SWAP (swap-out). Se liberaron ${p.pages} marcos de RAM.`);
  }

  /* ───── 7. Recuperar de SWAP ───── */
  function swapIn(pid: number) {
    const p = procs.find((x) => x.pid === pid);
    if (!p || !p.inSwap) return;
    const start = firstFit(frameMap, p.pages);
    if (start === -1) {
      if (freeFrames >= p.pages) {
        timeStamp("warn", `⚠ Swap-in de ${p.name} falló: hay ${freeFrames} marcos libres pero no contiguos (fragmentación externa). Compacte la memoria e intente de nuevo.`);
      } else {
        timeStamp("err", `✗ Swap-in de ${p.name} falló: se necesitan ${p.pages} marcos y solo hay ${freeFrames} libres.`);
      }
      return;
    }
    setProcs((ps) =>
      ps.map((x) => (x.pid === pid ? { ...x, inSwap: false, frames: Array.from({ length: p.pages }, (_, i) => start + i) } : x)),
    );
    timeStamp("ok", `✓ ${p.name} (PID ${pid}) recuperado del SWAP (swap-in) en los marcos ${start}–${start + p.pages - 1}. Nótese que puede quedar en una dirección distinta a la original.`);
  }

  /* ───── 8. Salir / reiniciar ───── */
  function salir() {
    setProcs([]);
    setNextPid(1);
    setSelectedPid(null);
    setLog([{ time: timeNow(), kind: "info", msg: "Gestor reiniciado. Todos los procesos fueron terminados y la memoria quedó libre." }]);
  }

  /* ───── Demo rápida ───── */
  function demo() {
    salir();
    setTimeout(() => {
      const demos: [string, number][] = [
        ["Chrome", 72],
        ["Spotify", 40],
        ["VSCode", 56],
        ["Excel", 36],
      ];
      let pid = 1;
      let map: (number | null)[] = Array(NUM_FRAMES).fill(null);
      const created: Proceso[] = [];
      for (const [n, s] of demos) {
        const pages = Math.ceil(s / FRAME_SIZE);
        const start = firstFit(map, pages);
        if (start === -1) continue;
        const frames = Array.from({ length: pages }, (_, i) => start + i);
        frames.forEach((f) => (map[f] = pid));
        created.push({ pid, name: n, size: s, pages, frames, inSwap: false, color: PALETTE[(pid - 1) % PALETTE.length].bg });
        pid++;
      }
      setProcs(created);
      setNextPid(pid);
      setSelectedPid(1);
      setLog((l) => [...l, { time: timeNow(), kind: "ok", msg: `✓ Demo cargada: ${created.map((c) => `${c.name} (${c.size} KB)`).join(", ")}. Termine "Spotify" y cree uno nuevo para ver la fragmentación externa.` }]);
    }, 60);
  }

  const selected = procs.find((p) => p.pid === selectedPid) ?? null;

  return (
    <div className="space-y-6">
      {/* ── Barra de menú tipo consola ── */}
      <div className="overflow-hidden rounded-2xl border border-slate-700 bg-slate-900 shadow-xl">
        <div className="flex items-center gap-2 border-b border-slate-700 bg-slate-800 px-4 py-2.5">
          <span className="h-3 w-3 rounded-full bg-rose-500" />
          <span className="h-3 w-3 rounded-full bg-amber-400" />
          <span className="h-3 w-3 rounded-full bg-emerald-500" />
          <span className="ml-3 font-mono text-xs text-slate-300">gestor_memoria — RAM {RAM_KB} KB · {NUM_FRAMES} marcos × {FRAME_SIZE} KB</span>
        </div>

        <div className="grid gap-6 p-5 lg:grid-cols-[1fr_340px]">
          {/* ===== Columna izquierda: memoria ===== */}
          <div className="space-y-5">
            {/* 1. Mostrar memoria */}
            <div>
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <h4 className="font-mono text-sm font-semibold text-emerald-400">[1] Mostrar memoria — RAM física</h4>
                <div className="flex gap-3 font-mono text-[11px] text-slate-400">
                  <span>■ usados: {usedFrames}</span>
                  <span className="text-slate-500">□ libres: {freeFrames}</span>
                  <span className="text-amber-400">frag. interna: {intFrag} KB</span>
                </div>
              </div>

              <div className="grid grid-cols-8 gap-1.5">
                {frameMap.map((pid, i) => {
                  const p = pid !== null ? procs.find((x) => x.pid === pid) : null;
                  const isSel = p && p.pid === selectedPid;
                  return (
                    <button
                      key={i}
                      onClick={() => p && setSelectedPid(p.pid)}
                      title={p ? `Marco ${i} → ${p.name} (página ${p.frames!.indexOf(i)})` : `Marco ${i} · libre`}
                      className={`group relative flex h-11 flex-col items-center justify-center rounded-md border font-mono text-[10px] transition-all ${
                        p
                          ? `${p.color} border-transparent text-white ${isSel ? "ring-2 ring-white ring-offset-2 ring-offset-slate-900" : "opacity-90 hover:opacity-100"}`
                          : "border-dashed border-slate-600 bg-slate-800/60 text-slate-500 hover:border-slate-500"
                      }`}
                    >
                      <span className="font-bold leading-none">{p ? p.name.slice(0, 4) : "·"}</span>
                      <span className={`leading-none ${p ? "text-white/70" : ""}`}>{i}</span>
                    </button>
                  );
                })}
              </div>

              {/* barra de uso */}
              <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-slate-700">
                <div className="flex h-full">
                  {inRam
                    .slice()
                    .sort((a, b) => a.frames![0] - b.frames![0])
                    .map((p) => (
                      <div key={p.pid} className={`${p.color}`} style={{ width: `${(p.pages / NUM_FRAMES) * 100}%` }} title={`${p.name}: ${p.pages * FRAME_SIZE} KB`} />
                    ))}
                </div>
              </div>
              <div className="mt-1.5 flex justify-between font-mono text-[11px] text-slate-400">
                <span>0 KB</span>
                <span>
                  uso: {usedFrames * FRAME_SIZE} / {RAM_KB} KB ({Math.round((usedFrames / NUM_FRAMES) * 100)}%)
                </span>
                <span>{RAM_KB} KB</span>
              </div>

              {holes.length > 1 && (
                <p className="mt-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 font-mono text-[11px] text-amber-300">
                  ⚠ Fragmentación externa: {holes.length} huecos libres dispersos ({holes.map((h) => `${h.len * FRAME_SIZE} KB`).join(" + ")}). Use [4] Compactar.
                </p>
              )}
            </div>

            {/* 5. Mostrar páginas */}
            <div>
              <div className="mb-2 flex items-center justify-between">
                <h4 className="font-mono text-sm font-semibold text-emerald-400">[5] Mostrar páginas — tabla de páginas</h4>
                <button onClick={() => setShowPages((s) => !s)} className="font-mono text-[11px] text-slate-400 underline-offset-2 hover:text-slate-200 hover:underline">
                  {showPages ? "ocultar" : "mostrar"}
                </button>
              </div>
              {showPages &&
                (selected ? (
                  <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-4">
                    <div className="mb-3 flex flex-wrap items-center gap-2 font-mono text-xs text-slate-300">
                      <span className={`inline-block h-3 w-3 rounded-sm ${selected.color}`} />
                      <strong className="text-white">{selected.name}</strong>
                      <span>PID {selected.pid}</span>·<span>{selected.size} KB solicitados</span>·<span>{selected.pages} páginas de {FRAME_SIZE} KB</span>·
                      <span className="text-amber-400">frag. interna {selected.pages * FRAME_SIZE - selected.size} KB</span>
                      {selected.inSwap && <span className="rounded bg-violet-500/20 px-1.5 py-0.5 text-violet-300">EN SWAP</span>}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {Array.from({ length: selected.pages }, (_, i) => (
                        <div key={i} className="flex items-center gap-1.5 rounded-lg border border-slate-600 bg-slate-900 px-2.5 py-1.5 font-mono text-[11px]">
                          <span className="text-slate-400">pág {i}</span>
                          <span className="text-slate-500">→</span>
                          {selected.frames ? (
                            <span className="font-bold text-emerald-400">marco {selected.frames[i]}</span>
                          ) : (
                            <span className="font-bold text-violet-400">disco (swap)</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="rounded-xl border border-dashed border-slate-600 bg-slate-800/40 px-4 py-6 text-center font-mono text-xs text-slate-500">
                    Cree un proceso o haga clic sobre uno (en la RAM o en las tablas) para ver su tabla de páginas: página i → marco asignado.
                  </p>
                ))}
            </div>

            {/* Área de swap */}
            <div>
              <h4 className="mb-2 font-mono text-sm font-semibold text-violet-400">💾 Área de SWAP (disco)</h4>
              <div className="min-h-[64px] rounded-xl border border-violet-500/30 bg-violet-500/5 p-3">
                {inSwap.length === 0 ? (
                  <p className="py-2 text-center font-mono text-xs text-slate-500">— vacía — los procesos expulsados de RAM aparecerán aquí</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {inSwap.map((p) => (
                      <div key={p.pid} className="flex items-center gap-2 rounded-lg border border-violet-500/40 bg-slate-900 px-3 py-2">
                        <span className={`h-3 w-3 rounded-sm ${p.color}`} />
                        <button onClick={() => setSelectedPid(p.pid)} className="font-mono text-xs font-bold text-white hover:underline">
                          {p.name}
                        </button>
                        <span className="font-mono text-[10px] text-slate-400">{p.size} KB · {p.pages} pág</span>
                        <button onClick={() => swapIn(p.pid)} className="rounded bg-violet-600 px-2 py-0.5 font-mono text-[10px] font-bold text-white hover:bg-violet-500">
                          [7] recuperar ⬆
                        </button>
                        <button onClick={() => terminarProceso(p.pid)} className="rounded bg-slate-700 px-2 py-0.5 font-mono text-[10px] text-slate-300 hover:bg-rose-600 hover:text-white">
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ===== Columna derecha: menú de acciones ===== */}
          <div className="space-y-4">
            <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-4">
              <h4 className="mb-3 font-mono text-sm font-semibold text-emerald-400">[2] Crear proceso</h4>
              <label className="mb-1 block font-mono text-[11px] text-slate-400">Nombre (opcional)</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && crearProceso()}
                placeholder={`P${nextPid}`}
                className="mb-3 w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 font-mono text-sm text-white placeholder-slate-600 outline-none focus:border-emerald-500"
              />
              <label className="mb-1 block font-mono text-[11px] text-slate-400">
                Tamaño: <span className="font-bold text-white">{size} KB</span> → {Math.ceil(size / FRAME_SIZE)} páginas
              </label>
              <input type="range" min={4} max={160} step={4} value={size} onChange={(e) => setSize(+e.target.value)} className="mb-3 w-full accent-emerald-500" />
              <button onClick={crearProceso} className="w-full rounded-lg bg-emerald-600 py-2 font-mono text-sm font-bold text-white transition hover:bg-emerald-500">
                + Crear (primer ajuste)
              </button>
            </div>

            <div className="rounded-xl border border-slate-700 bg-slate-800/60 p-4">
              <h4 className="mb-2 font-mono text-sm font-semibold text-emerald-400">[3] Terminar · [6] SWAP</h4>
              {inRam.length === 0 ? (
                <p className="font-mono text-[11px] text-slate-500">No hay procesos en RAM.</p>
              ) : (
                <div className="space-y-1.5">
                  {inRam
                    .slice()
                    .sort((a, b) => a.frames![0] - b.frames![0])
                    .map((p) => (
                      <div key={p.pid} className={`flex items-center gap-2 rounded-lg border px-2.5 py-1.5 ${p.pid === selectedPid ? "border-slate-400 bg-slate-700/60" : "border-slate-700 bg-slate-900"}`}>
                        <span className={`h-3 w-3 shrink-0 rounded-sm ${p.color}`} />
                        <button onClick={() => setSelectedPid(p.pid)} className="min-w-0 flex-1 truncate text-left font-mono text-xs font-bold text-white hover:underline">
                          {p.name}
                          <span className="ml-1.5 font-normal text-slate-400">
                            {p.size}KB · m{p.frames![0]}–{p.frames![p.frames!.length - 1]}
                          </span>
                        </button>
                        <button onClick={() => swapOut(p.pid)} title="[6] Enviar a SWAP" className="rounded bg-violet-600/80 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white hover:bg-violet-500">
                          ⬇ swap
                        </button>
                        <button onClick={() => terminarProceso(p.pid)} title="[3] Terminar proceso" className="rounded bg-slate-700 px-1.5 py-0.5 font-mono text-[10px] text-slate-300 hover:bg-rose-600 hover:text-white">
                          ✕
                        </button>
                      </div>
                    ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button onClick={compactar} className="rounded-lg bg-amber-500 py-2 font-mono text-xs font-bold text-slate-900 transition hover:bg-amber-400">
                [4] Compactar
              </button>
              <button onClick={salir} className="rounded-lg bg-rose-600/90 py-2 font-mono text-xs font-bold text-white transition hover:bg-rose-500">
                [8] Salir / Reset
              </button>
              <button onClick={demo} className="col-span-2 rounded-lg border border-slate-600 bg-slate-800 py-2 font-mono text-xs font-bold text-slate-300 transition hover:border-slate-400 hover:text-white">
                ▶ Cargar escenario de demostración
              </button>
            </div>
          </div>
        </div>

        {/* ── Bitácora ── */}
        <div className="border-t border-slate-700 bg-slate-950/70 px-5 py-3">
          <h4 className="mb-1.5 font-mono text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bitácora del sistema operativo</h4>
          <div ref={logRef} className="max-h-36 space-y-1 overflow-y-auto pr-2">
            {log.map((e, i) => (
              <p
                key={i}
                className={`font-mono text-[11px] leading-relaxed ${
                  e.kind === "ok" ? "text-emerald-400" : e.kind === "warn" ? "text-amber-400" : e.kind === "err" ? "text-rose-400" : "text-slate-400"
                }`}
              >
                <span className="text-slate-600">[{e.time}]</span> {e.msg}
              </p>
            ))}
          </div>
        </div>
      </div>

      {/* leyenda didáctica */}
      <div className="grid gap-3 text-sm sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="font-semibold text-slate-800">💡 Pruebe la fragmentación</p>
          <p className="mt-1 text-slate-600">Cargue la demo, termine un proceso intermedio y cree uno grande: no cabrá aunque haya memoria libre total suficiente.</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="font-semibold text-slate-800">💡 Compactación</p>
          <p className="mt-1 text-slate-600">Con [4] los procesos se desplazan al inicio de la RAM y los huecos dispersos se fusionan en un único bloque contiguo.</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="font-semibold text-slate-800">💡 Swapping</p>
          <p className="mt-1 text-slate-600">Con [6] el proceso completo pasa al disco liberando sus marcos; con [7] vuelve a RAM, posiblemente en otra dirección.</p>
        </div>
      </div>
    </div>
  );
}

function timeNow() {
  return new Date().toLocaleTimeString("es-CO", { hour12: false });
}
