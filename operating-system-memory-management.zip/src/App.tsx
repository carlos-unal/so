import { useState } from "react";
import { sections } from "./data/answers";
import { pythonCode } from "./data/pythonCode";
import Simulator from "./components/Simulator";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <Header />
      <Nav />
      <main className="mx-auto max-w-5xl space-y-14 px-4 pb-24 pt-12 sm:px-6">
        {sections.map((s) => (
          <QASection key={s.id} section={s} />
        ))}
        <SimulatorSection />
        <CodeSection />
      </main>
      <Footer />
    </div>
  );
}

/* ───────────── Header ───────────── */

function Header() {
  return (
    <header className="relative overflow-hidden bg-slate-900 text-white">
      <div className="pointer-events-none absolute inset-0 opacity-20" aria-hidden>
        <div className="absolute -left-20 top-10 h-72 w-72 rounded-full bg-sky-500 blur-3xl" />
        <div className="absolute right-0 top-32 h-80 w-80 rounded-full bg-violet-600 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-64 w-64 rounded-full bg-emerald-500 blur-3xl" />
      </div>
      <div className="relative mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-20">
        <p className="mb-3 inline-block rounded-full border border-white/20 bg-white/10 px-4 py-1 font-mono text-xs tracking-wider text-sky-300">
          TALLER · SISTEMAS OPERATIVOS · GESTIÓN DE MEMORIA
        </p>
        <h1 className="max-w-3xl text-4xl font-black leading-tight tracking-tight sm:text-5xl">
          ¿Cómo administra la memoria un <span className="bg-gradient-to-r from-sky-400 via-emerald-400 to-violet-400 bg-clip-text text-transparent">Sistema Operativo</span>?
        </h1>
        <p className="mt-4 max-w-2xl text-slate-300">
          Solución del taller con respuestas sintéticas a los cinco bloques de preguntas y un{" "}
          <strong className="text-white">gestor de memoria mínimo funcional</strong> (punto 6): particiones, paginación, compactación y swapping en acción.
        </p>
        <div className="mt-6 flex flex-wrap gap-2 font-mono text-[11px] text-slate-300">
          {["RAM 256 KB", "32 marcos × 8 KB", "Primer ajuste", "Paginación", "Compactación", "Swapping"].map((t) => (
            <span key={t} className="rounded-md border border-white/15 bg-white/5 px-2.5 py-1">
              {t}
            </span>
          ))}
        </div>
      </div>
    </header>
  );
}

/* ───────────── Navegación ───────────── */

function Nav() {
  const links = [
    ...sections.map((s) => ({ href: `#${s.id}`, label: `${s.number}. ${s.title.split(" ")[0]}…` })),
    { href: "#gestor", label: "6. Gestor de memoria" },
    { href: "#codigo", label: "Código fuente" },
  ];
  return (
    <nav className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl gap-1 overflow-x-auto px-4 py-2 sm:px-6">
        {links.map((l) => (
          <a
            key={l.href}
            href={l.href}
            className="whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-900 hover:text-white"
          >
            {l.label}
          </a>
        ))}
      </div>
    </nav>
  );
}

/* ───────────── Secciones de preguntas ───────────── */

function QASection({ section }: { section: (typeof sections)[number] }) {
  return (
    <section id={section.id} className="scroll-mt-20">
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-xl shadow-md">{section.icon}</span>
        <div>
          <p className="font-mono text-[11px] font-bold uppercase tracking-wider text-sky-600">Bloque {section.number}</p>
          <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">{section.title}</h2>
        </div>
      </div>
      <div className="space-y-3">
        {section.items.map((qa, i) => (
          <article key={i} className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-sky-300 hover:shadow-md">
            <h3 className="flex items-start gap-2 font-bold text-slate-900">
              <span className="mt-0.5 shrink-0 rounded-md bg-sky-100 px-1.5 py-0.5 font-mono text-[11px] font-bold text-sky-700">
                {section.number}.{i + 1}
              </span>
              {qa.question}
            </h3>
            <p className="mt-2 pl-10 leading-relaxed text-slate-600">{qa.answer}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

/* ───────────── Punto 6: simulador ───────────── */

function SimulatorSection() {
  return (
    <section id="gestor" className="scroll-mt-20">
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-xl shadow-md">🖥️</span>
        <div>
          <p className="font-mono text-[11px] font-bold uppercase tracking-wider text-emerald-600">Bloque 6 · Práctica</p>
          <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">Gestor de memoria mínimo (interactivo)</h2>
        </div>
      </div>
      <p className="mb-6 max-w-3xl text-slate-600">
        Implementación funcional de las <strong>8 opciones del menú</strong> del taller: la RAM se modela como 32 marcos de 8 KB, los procesos se asignan por{" "}
        <strong>primer ajuste</strong> en marcos contiguos, cada proceso tiene su <strong>tabla de páginas</strong>, y se puede <strong>compactar</strong> la memoria y hacer{" "}
        <strong>swap-out / swap-in</strong> contra el área de disco.
      </p>
      <Simulator />
    </section>
  );
}

/* ───────────── Código fuente Python ───────────── */

function CodeSection() {
  const [open, setOpen] = useState(true);
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(pythonCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard no disponible */
    }
  }

  return (
    <section id="codigo" className="scroll-mt-20">
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-xl shadow-md">🐍</span>
        <div>
          <p className="font-mono text-[11px] font-bold uppercase tracking-wider text-violet-600">Entrega · Punto 6</p>
          <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">Código fuente del gestor (Python · consola)</h2>
        </div>
      </div>
      <p className="mb-4 max-w-3xl text-slate-600">
        Versión de consola del mismo gestor, limpia y tabulada, lista para ejecutar con <code className="rounded bg-slate-200 px-1.5 py-0.5 font-mono text-sm">python gestor_memoria.py</code> y
        para la exposición de 5 minutos.
      </p>
      <div className="overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-700 bg-slate-900 px-4 py-2.5">
          <span className="font-mono text-xs text-slate-300">gestor_memoria.py</span>
          <div className="flex gap-2">
            <button
              onClick={copy}
              className="rounded-md border border-slate-600 px-2.5 py-1 font-mono text-[11px] text-slate-300 transition hover:border-emerald-500 hover:text-emerald-400"
            >
              {copied ? "✓ copiado" : "copiar"}
            </button>
            <button
              onClick={() => setOpen((o) => !o)}
              className="rounded-md border border-slate-600 px-2.5 py-1 font-mono text-[11px] text-slate-300 transition hover:border-slate-400"
            >
              {open ? "contraer" : "expandir"}
            </button>
          </div>
        </div>
        {open && (
          <pre className="max-h-[560px] overflow-auto p-5 font-mono text-[12.5px] leading-relaxed text-slate-200">
            <code>{pythonCode}</code>
          </pre>
        )}
      </div>
    </section>
  );
}

/* ───────────── Footer ───────────── */

function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <div className="grid gap-6 sm:grid-cols-3">
          <div>
            <h4 className="font-bold text-slate-900">Taller · Gestión de Memoria</h4>
            <p className="mt-1 text-sm text-slate-500">Curso de Sistemas Operativos · Entrega por UNvirtual.</p>
          </div>
          <div>
            <h4 className="font-bold text-slate-900">Integrantes del equipo</h4>
            <ul className="mt-1 space-y-0.5 text-sm text-slate-500">
              <li>• Integrante 1 — (nombre completo)</li>
              <li>• Integrante 2 — (nombre completo)</li>
              <li>• Integrante 3 — (nombre completo)</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-slate-900">Entrega</h4>
            <p className="mt-1 text-sm text-slate-500">
              Fecha límite: jueves 08 de octubre de 2026, 11:55 a.m.
              <br />
              Exposición: máximo 5 minutos.
            </p>
          </div>
        </div>
        <p className="mt-8 text-center font-mono text-[11px] text-slate-400">RAM · MMU · páginas · marcos · swap — «la memoria es la ilusión mejor administrada del computador»</p>
      </div>
    </footer>
  );
}
